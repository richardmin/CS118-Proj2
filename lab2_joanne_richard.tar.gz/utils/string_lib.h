#ifndef string_lib_h
#define string_lib_h

#include <string>

char* stringToCString(std::string s);


#endif